export default function App() {
  return (
    <div className="text-center p-10 text-2xl text-green-600">Dobrodošli na ALPHA CORE demo stranicu!</div>
  );
}